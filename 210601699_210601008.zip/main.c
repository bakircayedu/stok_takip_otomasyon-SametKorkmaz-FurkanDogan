#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int urun_miktari = 0;
char urun_kategorileri[8][50] = {"Atistirmalik", "Icecek", "Temel Gida", "Et Urunleri", "Temizlik & Ev Gerecleri", "Kisisel Bakim", "Sut & Kahvaltılık"};

FILE *pDosya;
struct urun
{
    char isim[30];
    int urun_kodu, urun_satis_fiyati, stok_miktari, kategori;
} urun_listesi[50];

struct tedarikci
{
    char isim[30], adres[100];
    int no;
} tedarikci_listesi[5];

struct urun_stok
{
    int urun_kodu, alis_miktari, alis_fiyati, tarih, tedarikci_no;
} urun_stok_listesi[50];
void dosyaYaz(int m)
{

    fprintf(pDosya, "%s %s %s", "Ürün Kategorisi: ", urun_kategorileri[urun_listesi[m].kategori], "\n");
    fprintf(pDosya, "%s %s %s", "Ürün İsmi: ", urun_listesi[m].isim, "\n");
    fprintf(pDosya, "%s %d %s", "Ürun Kodu: ", urun_listesi[m].urun_kodu, "\n");
    fprintf(pDosya, "%s %d %s", "Ürun Satış Fiyatı:", urun_listesi[m].urun_satis_fiyati, "\n");
    fprintf(pDosya, "%s %d %s", "Ürün Stok miktari: ", urun_listesi[m].stok_miktari, "\n\n");
}
void urunleriOku()
{
    char cumle[100];
    pDosya = fopen("urunListesi.txt", "r");
    if (pDosya == NULL)
    {
        printf("Hata! Dosyaya urun yazilmamais.\n");
        fclose(pDosya);
    }
    else
    {
        printf("\n");
        while (feof(pDosya) == 0)
        {
            fgets(cumle, 100, pDosya);
            printf("%s", cumle);
        }
    }
}

void dosyaKontrol(int m)
{

    pDosya = fopen("urunListesi.txt", "r");
    if (pDosya == NULL)
    {
        fclose(pDosya);
        pDosya = fopen("urunListesi.txt", "w+");
        dosyaYaz(m);
        fclose(pDosya);
    }
    else
    {
        fclose(pDosya);
        pDosya = fopen("urunListesi.txt", "a+");
        dosyaYaz(m);
        fclose(pDosya);
    }
}

void urun_gir()
{

    int i = 1, kategori_sayi;
    printf("Girmek istediginiz urun kategorisini seciniz:\n");
    for (i = 0; i < 7; i++)
    {
        printf("%s (%d)\n", urun_kategorileri[i], i + 1);
    }

    scanf("%d", &kategori_sayi);
    urun_listesi[urun_miktari].kategori = kategori_sayi - 1;
    printf("%s Kategorisi\n", urun_kategorileri[kategori_sayi - 1]);
    printf("Urun ismini giriniz: ");
    scanf(" %[^\n]", &urun_listesi[urun_miktari].isim);
    printf("Urun kodunu giriniz: ");
    scanf("%d", &urun_listesi[urun_miktari].urun_kodu);
    printf("Urun satis fiyatini giriniz: ");
    scanf("%d", &urun_listesi[urun_miktari].urun_satis_fiyati);
    printf("Stok miktarini giriniz: ");
    scanf("%d", &urun_listesi[urun_miktari].stok_miktari);
    printf("\n");
    dosyaKontrol(urun_miktari);
    urun_miktari += 1;
}

int main()
{

    int k = 1, komut, urunSon;
    while (k == 1)
    {
        printf("Merhaba. Urun islemleri icin 1, Tedarikci firma girisi icin 2, Urun stok girisi 3 yaziniz, Programdan cıkıs icin 4 yaziniz.\n");
        scanf("%d", &komut);
        switch (komut)
        {
        case 1:
            printf("Yeni urun girmek icin 1, mevcut urunleri goruntulemek icin 2 ,geri donmek icin 4 yaziniz: ");
            scanf("%d", &komut);
            if (komut == 1)
            {
                urun_gir();
                break;
            }
            else if (komut == 2)
            {
                urunleriOku();
                break;
            }
            else if (komut == 4)
            {
                break;
            }

            break;
        case 4:
            k = 0;
            break;
        default:
            break;
        }
    }
}
